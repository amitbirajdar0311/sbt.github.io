<?php

include './config.php';
$companySelect = mysqli_real_escape_string($con, $_POST['companySelect']);
$selectedCompanyAddress = mysqli_real_escape_string($con, $_POST['selectedCompanyAddress']);
$invoiceDate = mysqli_real_escape_string($con, $_POST['invoiceDate']);
$invoiceNumber = mysqli_real_escape_string($con, $_POST['invoiceNumber']);
$requestId = mysqli_real_escape_string($con, $_POST['requestid']);
$bookedBy = mysqli_real_escape_string($con, $_POST['bookedBy']);

$PassengerName = mysqli_real_escape_string($con, $_POST['PassengerName']);

$FromDate = mysqli_real_escape_string($con, $_POST['invoiceDate']);
$ToDate = mysqli_real_escape_string($con, $_POST['invoiceDate1']);
$car = mysqli_real_escape_string($con, $_POST['car']);
$VehicleNumber = mysqli_real_escape_string($con, $_POST['Vno']);
$selectedDuty = mysqli_real_escape_string($con, $_POST['selectedDuty']);
$rate = mysqli_real_escape_string($con, $_POST['rate']);
$dutyAmt = mysqli_real_escape_string($con, $_POST['dutyAmt']);
// $DutySlip = mysqli_real_escape_string($con, $_POST['uploadDuty']);
// '$DutySlip',
$extHrs = mysqli_real_escape_string($con, $_POST['extHrs']);
$myQty = mysqli_real_escape_string($con, $_POST['myQty']);
$extHAmt = mysqli_real_escape_string($con, $_POST['extHAmt']);
$exKm = mysqli_real_escape_string($con, $_POST['exKm']);
$extKms = mysqli_real_escape_string($con, $_POST['extKms']);
$extKAmt = mysqli_real_escape_string($con, $_POST['extKAmt']);
$pnt = mysqli_real_escape_string($con, $_POST['pnt']);
// $ParkingandTollSlip = mysqli_real_escape_string($con, $_POST['uploadPaT']);'$ParkingandTollSlip',
$na = mysqli_real_escape_string($con, $_POST['na']);
$totalAmount = mysqli_real_escape_string($con, $_POST['totalAmount']);


// create the SQL query for inserting into the database
$insertData = "INSERT INTO invoice_form( Company, InvoieceDate, InvoiceNumber, ReqId, bookedBy, PassengerName, FromDate, ToDate, VehicleGroup, VehicleNumber, DutyType, Rate, dutyAmt, ExtraHrs, myQtyHrs, extHAmt, ExtraKms, myQtyKms, extKAmt, ParkingandToll, NightAllownace, Total) VALUES ('$companySelect','$selectedCompanyAddress','$invoiceDate','$invoiceNumber','$requestId','$bookedBy','$PassengerName','$FromDate','$ToDate','$car','$VehicleNumber','$selectedDuty','$rate','$dutyAmt','$extHrs','$myQty','$extHAmt','$exKm','$extKms','$extKAmt','$pnt','$na','$totalAmount')";


$con -> query($insertData)

?>
