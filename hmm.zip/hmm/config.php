<?php 
    error_reporting(0);
    $servername= "localhost";
    $username = "root";
    $database = "abcreation";

    $con = new mysqli($servername, $username, "", $database);

    session_start()

?>